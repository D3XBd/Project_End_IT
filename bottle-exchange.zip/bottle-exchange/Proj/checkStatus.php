<?php
if (file_exists("active_user.txt")) {
    echo "EXCHANGE";
} else {
    echo "IDLE";
}
?>